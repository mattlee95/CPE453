//Global defines

#ifndef GLOBALS_H
#define GLOBALS_H

//place defines and prototypes here
char song_name[100];
unsigned int curr_song_idx;
unsigned int num_songs;
unsigned int song_inodes[8]; 
unsigned int song_dur;
unsigned int curr_dur;

#endif
